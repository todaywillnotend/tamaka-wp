<?php

namespace FcfVendor;

/**
 * @deprecated Have typo so better use WPDesk_Translatable
 */
interface WPDesk_Translable
{
    /** @return string */
    public function get_text_domain();
}
