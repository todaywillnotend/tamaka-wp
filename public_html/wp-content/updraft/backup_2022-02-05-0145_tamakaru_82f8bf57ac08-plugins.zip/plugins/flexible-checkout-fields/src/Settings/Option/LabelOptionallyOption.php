<?php

namespace WPDesk\FCF\Free\Settings\Option;

/**
 * {@inheritdoc}
 */
class LabelOptionallyOption extends LabelOption {

	/**
	 * {@inheritdoc}
	 */
	public function get_validation_rules(): array {
		return [];
	}
}
