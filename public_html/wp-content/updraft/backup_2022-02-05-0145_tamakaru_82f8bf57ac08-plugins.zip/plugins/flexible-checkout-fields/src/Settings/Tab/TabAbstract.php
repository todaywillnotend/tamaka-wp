<?php

namespace WPDesk\FCF\Free\Settings\Tab;

/**
 * {@inheritdoc}
 */
abstract class TabAbstract implements TabInterface {

}
