<?php

namespace WPDesk\FCF\Free\Settings\Form;

/**
 * {@inheritdoc}
 */
abstract class FormAbstract implements FormInterface {

}
