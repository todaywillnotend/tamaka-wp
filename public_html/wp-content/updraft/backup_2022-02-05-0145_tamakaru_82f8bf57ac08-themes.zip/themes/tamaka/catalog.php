<?php /* Template name: Каталог */ get_header();?>
		<main class="main catalog">
			<section class="popular">
  <div class="container">
    <h1>КАТАЛОГ ЖЕНСКОЙ ОДЕЖДЫ</h1>
    <div class="popular__content">
      <div class="popular__card">
        <img src="img/new-card.png" alt="popular-card" />
        <span class="popular__card__title">ХАЛАТ</span>
        <span class="popular__card__price">2399 рублей</span>
      </div>
      <div class="popular__card">
        <img src="img/new-card.png" alt="popular-card" />
        <span class="popular__card__title">ЛЕТНИЙ ХАЛАТ</span>
        <span class="popular__card__price">2399 рублей</span>
      </div>
      <div class="popular__card">
        <img src="img/new-card.png" alt="popular-card" />
        <span class="popular__card__title">ЛЕТНИЙ ХАЛАТ</span>
        <span class="popular__card__price">2399 рублей</span>
      </div>
      <div class="popular__card">
        <img src="img/new-card.png" alt="popular-card" />
        <span class="popular__card__title">ХАЛАТ</span>
        <span class="popular__card__price">2399 рублей</span>
      </div>
    </div>
  </div>
</section> <section class="pagination">
	<div class="container">
		<div class="pagination__content">
			<a href="#">&laquo;</a>
			<a class="active" href="#">1</a>
			<a href="#">2</a>
			<a href="#">3</a>
			<a href="#">&raquo;</a>
		</div>
	</div>
</section>
			<section class="info">
  <div class="container">
    <div class="info__text">
      <span>Интернет магазин одежды</span>
      <p>
        Мы развивающийся бренд ...Широчайший ассортимент модной и стильной
        одежды представлен в интернет-магазине. Коллекции качественной и
        недорогой одежды постоянно обновляются: на сайте можно найти как
        актуальные новинки, так и базовые вещи «вне времени», которые актуальны
        всегда.
      </p>
    </div>
  </div>
</section>

		</main>
<? get_footer();